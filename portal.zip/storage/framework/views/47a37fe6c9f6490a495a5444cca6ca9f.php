<!DOCTYPE html>
<html lang="en">
<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title', 'description', 'keywords']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title', 'description', 'keywords']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="<?php echo e($description ?? ''); ?>">
    <meta name="keywords" content="<?php echo e($keywords ?? ''); ?>">
    <title>Jawaaf News | <?php echo e($title ?? 'Home'); ?></title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>" type="image/x-icon">

    <link rel="stylesheet" href="<?php echo e(asset('frontend/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fontawesome-free-6.7.2-web/css/all.min.css')); ?>">
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal13d15359433bf6f639ab09ce227bb8ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13d15359433bf6f639ab09ce227bb8ea = $attributes; } ?>
<?php $component = App\View\Components\FrontendHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontendHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13d15359433bf6f639ab09ce227bb8ea)): ?>
<?php $attributes = $__attributesOriginal13d15359433bf6f639ab09ce227bb8ea; ?>
<?php unset($__attributesOriginal13d15359433bf6f639ab09ce227bb8ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13d15359433bf6f639ab09ce227bb8ea)): ?>
<?php $component = $__componentOriginal13d15359433bf6f639ab09ce227bb8ea; ?>
<?php unset($__componentOriginal13d15359433bf6f639ab09ce227bb8ea); ?>
<?php endif; ?>

    <main>
        <?php echo e($slot); ?>

    </main>

    <?php if (isset($component)) { $__componentOriginale896d2e37756d2f745b6dce807f3d1c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale896d2e37756d2f745b6dce807f3d1c6 = $attributes; } ?>
<?php $component = App\View\Components\FrontendFooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontendFooter::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale896d2e37756d2f745b6dce807f3d1c6)): ?>
<?php $attributes = $__attributesOriginale896d2e37756d2f745b6dce807f3d1c6; ?>
<?php unset($__attributesOriginale896d2e37756d2f745b6dce807f3d1c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale896d2e37756d2f745b6dce807f3d1c6)): ?>
<?php $component = $__componentOriginale896d2e37756d2f745b6dce807f3d1c6; ?>
<?php unset($__componentOriginale896d2e37756d2f745b6dce807f3d1c6); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH E:\laravel\news_portal\resources\views/components/frontend-layout.blade.php ENDPATH**/ ?>