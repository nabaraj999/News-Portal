
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header justify-content-between">
                            <h4>Article Edit</h4>
                            <a href="<?php echo e(route('admin.article.index')); ?>" class="btn btn-primary">go back</a>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.article.update', $article->id)); ?>" method="post"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">

                                    <div class="col-6 pb-2">
                                        <label for="categories">Select Categories</label>
                                        <select name="categories[]" id="categories" class="form-control select2"
                                            multiple="multiple">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>"
                                                    <?php echo e($article->categories->contains($category->id) ? 'selected' : ''); ?>>
                                                    <?php echo e($category->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="title">Enter Title</label>
                                        <input type="text" name="title" id="title" class="form-control"
                                            value="<?php echo e($article->title); ?>">
                                    </div>

                                    <div class="col-12 pb-2">
                                        <label for="content">Enter Content</label>
                                        <textarea name="content" id="content" class="form-control summernote">
                                            <?php echo e($article->content); ?>

                                        </textarea>
                                    </div>

                                    <div class="col-12 pb-2">
                                        <label for="meta_keywords">Enter Meta Keywords</label>
                                        <textarea name="meta_keywords" id="meta_keywords" class="form-control">
                                            <?php echo e($article->meta_keywords); ?>

                                        </textarea>
                                    </div>

                                    <div class="col-12 pb-2">
                                        <label for="description">Enter Meta Description</label>
                                        <textarea name="description" id="description" class="form-control">
                                            <?php echo e($article->meta_keywords); ?>

                                        </textarea>
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="image">Upload Image</label>
                                        <input type="file" name="image" id="image" class="form-control">
                                        <img src="<?php echo e(asset($article->image)); ?>" height="200" alt="">
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="name">Change Status</label>
                                        <select name="status" id="status" class="form-control">
                                            <option value="pending"
                                                <?php echo e($article->status == 'pending' ? 'selected' : ''); ?>>
                                                Pending</option>
                                            <option value="approved"
                                                <?php echo e($article->status == 'approved' ? 'selected' : ''); ?>>
                                                Approved</option>
                                            <option value="rejected"
                                                <?php echo e($article->status == 'rejected' ? 'selected' : ''); ?>>
                                                Rejected</option>
                                        </select>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p>
                                                <span class="text-danger"><?php echo e($message); ?></span>
                                            </p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="col-12">
                                        <button type="submit" class="btn btn-success">Save Record</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\news_portal\resources\views/admin/article/edit.blade.php ENDPATH**/ ?>