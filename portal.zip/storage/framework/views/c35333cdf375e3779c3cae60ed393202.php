<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="section">
        <div class="section-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header justify-content-between">
                            <h4>Company Edit</h4>
                            <a href="<?php echo e(route('admin.company.index')); ?>" class="btn btn-primary">go back</a>
                        </div>
                        <div class="card-body">
                            <form action="<?php echo e(route('admin.company.update', $company->id)); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row">
                                    <div class="col-6 pb-2">
                                        <label for="name">Enter Company Name</label>
                                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e($company->name); ?>">
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="email">Enter Company Email</label>
                                        <input type="text" name="email" id="email" class="form-control" value="<?php echo e($company->email); ?>">
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="phone">Enter Company Phone</label>
                                        <input type="text" name="phone" id="phone" class="form-control" value="<?php echo e($company->phone); ?>">
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="youtube">Enter Youtube link</label>
                                        <input type="text" name="youtube" id="youtube" class="form-control" value="<?php echo e($company->youtube); ?>">
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="facebook">Enter Facebook Link</label>
                                        <input type="text" name="facebook" id="facebook" class="form-control" value="<?php echo e($company->facebook); ?>">
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="instagram">Enter Instagram Link</label>
                                        <input type="text" name="instagram" id="instagram" class="form-control" value="<?php echo e($company->instagram); ?>">
                                    </div>

                                    <div class="col-6 pb-2">
                                        <label for="logo">Upload Company Logo</label>
                                        <input type="file" name="logo" id="logo" class="form-control">
                                        <img src="<?php echo e(asset($company->logo)); ?>" width="120" alt="">
                                    </div>

                                    <div class="col-12">
                                        <button type="submit" class="btn btn-success">Update Record</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH E:\laravel\news_portal\resources\views/admin/company/edit.blade.php ENDPATH**/ ?>