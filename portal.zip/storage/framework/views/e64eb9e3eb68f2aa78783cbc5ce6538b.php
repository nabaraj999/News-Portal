<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>

    <link rel="stylesheet" href="<?php echo e(asset('frontend/style.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('fontawesome-free-6.7.2-web/css/all.min.css')); ?>">
</head>

<body>
    <?php if (isset($component)) { $__componentOriginal13d15359433bf6f639ab09ce227bb8ea = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal13d15359433bf6f639ab09ce227bb8ea = $attributes; } ?>
<?php $component = App\View\Components\FrontendHeader::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontendHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal13d15359433bf6f639ab09ce227bb8ea)): ?>
<?php $attributes = $__attributesOriginal13d15359433bf6f639ab09ce227bb8ea; ?>
<?php unset($__attributesOriginal13d15359433bf6f639ab09ce227bb8ea); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal13d15359433bf6f639ab09ce227bb8ea)): ?>
<?php $component = $__componentOriginal13d15359433bf6f639ab09ce227bb8ea; ?>
<?php unset($__componentOriginal13d15359433bf6f639ab09ce227bb8ea); ?>
<?php endif; ?>

    <main>
        <?php echo e($slot); ?>

    </main>

    <?php if (isset($component)) { $__componentOriginale896d2e37756d2f745b6dce807f3d1c6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale896d2e37756d2f745b6dce807f3d1c6 = $attributes; } ?>
<?php $component = App\View\Components\FrontendFooter::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('frontend-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontendFooter::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale896d2e37756d2f745b6dce807f3d1c6)): ?>
<?php $attributes = $__attributesOriginale896d2e37756d2f745b6dce807f3d1c6; ?>
<?php unset($__attributesOriginale896d2e37756d2f745b6dce807f3d1c6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale896d2e37756d2f745b6dce807f3d1c6)): ?>
<?php $component = $__componentOriginale896d2e37756d2f745b6dce807f3d1c6; ?>
<?php unset($__componentOriginale896d2e37756d2f745b6dce807f3d1c6); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH C:\Users\Nabu\OneDrive\Desktop\laravel\news_portal\resources\views/components/frontend-layout.blade.php ENDPATH**/ ?>