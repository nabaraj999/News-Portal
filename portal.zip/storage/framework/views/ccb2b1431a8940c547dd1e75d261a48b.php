<div>
    <!-- Walk as if you are kissing the Earth with your feet. - Thich Nhat Hanh -->
</div><?php /**PATH C:\Users\Nabu\OneDrive\Desktop\laravel\news_portal\resources\views/components/frontend-footer.blade.php ENDPATH**/ ?>