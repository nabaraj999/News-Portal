
 <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['article']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['article']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

 <div class="flex text-xs gap-2 items-center shadow hover:shadow-lg">
     <a href="<?php echo e(route('article', $article->id)); ?>">
         <img class="w-1/3" src="<?php echo e(asset($article->image)); ?>" alt="<?php echo e($article->title); ?>">
     </a>
     <div>
         <h3 class="text-sm font-semibold line-clamp-1">
             <?php echo e($article->title); ?>

         </h3>
         <div class="line-clamp-1">
             <?php echo $article->content; ?>

         </div>
         <div class="flex justify-between">
             <small>
                 <?php echo e(nepalidate($article->created_at)); ?>

             </small>
             <a href="">read more</a>
         </div>
     </div>
 </div>
<?php /**PATH E:\laravel\news_portal\resources\views/components/article-card.blade.php ENDPATH**/ ?>